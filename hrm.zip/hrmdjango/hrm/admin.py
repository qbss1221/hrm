from django.contrib import admin
#
# from .models import  Staff,Department
#
# class StaffAdmin(admin.ModelAdmin):
#     pass
#
# admin.site.register(Staff,StaffAdmin)
#
# class DepartmentAdmin(admin.ModelAdmin):
#     pass
#
# admin.site.register(Department,DepartmentAdmin)

