# _*_ coding:utf-8 _*_
__author__='qbss'

import xadmin

from .models import Department,Staff,EmailVerifyRecord

class DepartmentAdmin(object):
    list_display=('name','number','manager')

xadmin.site.register(Department,DepartmentAdmin)


class StaffAdmin(object):
    list_display = ('name','add_time')

xadmin.site.register(Staff,StaffAdmin)


class EmailVerifyRecordAdmin(object):
    list_display = ('code', 'email')

xadmin.site.register(EmailVerifyRecord,EmailVerifyRecordAdmin)
