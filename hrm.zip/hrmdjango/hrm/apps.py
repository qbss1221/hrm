from django.apps import AppConfig


class HrmConfig(AppConfig):
    name = 'hrm'
