# _*_ coding:utf-8 _*_
from datetime import datetime

from django.db import models

class Department(models.Model):
    name=models.CharField(max_length=20,verbose_name=u"部门名称",default="")
    number=models.IntegerField(verbose_name=u"部门人数")
    manager=models.CharField(max_length=10,verbose_name=u"部门经理",default="")

    class Meta:
        verbose_name=u"部门信息"
        verbose_name_plural=verbose_name
        db_table="department_message"

    def __unicode__(self):
        return self.name


class Staff(models.Model):
    department = models.ForeignKey(Department, verbose_name="部门",null=True,blank=True)
    name=models.CharField(max_length=20,verbose_name=u"员工姓名")
    email=models.EmailField(default='1.com',verbose_name=u"邮箱")
    address=models.CharField(max_length=50,verbose_name=u"住址",default='2')
    sex=models.CharField(max_length=10,choices=(('female',u'女'),('male',u'男')),verbose_name=u"性别")
    age=models.IntegerField(verbose_name=u"年龄")
    birthday=models.DateField(verbose_name=u"生日")
    tel=models.CharField(max_length=20,verbose_name=u"手机号")
    add_time = models.DateTimeField(default=datetime.now, verbose_name=u"入职时间")

    class Meta:
        verbose_name=u"员工信息表"
        verbose_name_plural = verbose_name
        db_table="staff_message"

    def __unicode__(self):
        return self.name



class EmailVerifyRecord(models.Model):
    code=models.CharField(max_length=20,verbose_name="验证码")
    email=models.EmailField(max_length=50,verbose_name="邮箱")
    send_type=models.CharField(choices=(("register",u"注册"),("forget",u"忘记密码")),max_length=20,verbose_name="验证码类型")
    send_time=models.DateTimeField(default=datetime.now,verbose_name="验证时间")

    class Meta:
        verbose_name=u"邮箱验证码"
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return '{0}({1})'.format(self.code,self.email)